#! /bin/sh

#iptables -I FORWARD -p tcp -m string --string "greatfire.org" --algo bm -j DROP
#iptables -D FORWARD -p tcp -m string --string "greatfire.org" --algo bm -j DROP

echo \#! /bin/sh
for domain in $(cat blocklist); do
     echo iptables -I FORWARD -p tcp -m string --string \"$domain\" --algo bm -j DROP
done
