#! /bin/sh

/work/zabbix/sbin/zabbix_agentd -c /work/zabbix/conf/zabbix_agentd.conf

chmod +x /work/wireguard/*
chmod +x /work/*.sh
chmod +x /work/sh/*.sh
cp /work/wireguard/wg /sbin/


nohup /work/wireguard/wg-agent >/work/log/wg-agent.log &
nohup /work/wireguard/wireguard-go -f wg0 check >/work/log/wg0.log &
nohup /work/wireguard/wireguard-go -f wg1 >/work/log/wg1.log &


WORK=/work/sh/
cd $WORK

#随机生成密钥
wg genkey > /tmp/private.wg0
wg pubkey < /tmp/private.wg0 > /tmp/public.wg0

sleep 10
ip link add wg0 type wireguard
ip addr add $WG0_ADDR dev wg0
wg set wg0 private-key /tmp/private.wg0
ip link set wg0 up
wg set wg0 listen-port $WG0_PORT

echo "net.ipv4.conf.all.rp_filter = 0">/etc/sysctl.conf
echo "net.ipv4.conf.default.rp_filter = 0" >>/etc/sysctl.conf
echo "net.ipv4.conf.eth0.rp_filter = 0" >>/etc/sysctl.conf
echo "net.ipv4.conf.wg0.rp_filter = 0" >>/etc/sysctl.conf
echo "net.ipv4.conf.wg1.rp_filter = 0" >>/etc/sysctl.conf
sysctl -p

iptables -A FORWARD -i wg0 -j ACCEPT
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
ip6tables -A FORWARD -i wg0 -j ACCEPT
ip6tables -t nat -A POSTROUTING -o eth0 -j MASQUERADE


while [ 1 ]; do
    sleep 65565
done
