#! /bin/sh

chmod +x /work/wireguard/*
chmod +x /work/*.sh
chmod +x /work/sh/*.sh
cp /work/wireguard/wg /sbin/


nohup /work/wireguard/wireguard-go -f wg0 check >null &
nohup /work/wireguard/wireguard-go -f wg1 >null &


WORK=/work/sh/
cd $WORK

echo $PRIVATE_WG0 > /tmp/private.wg0
sleep 10
ip link add wg0 type wireguard
ip addr add $WG0_ADDR dev wg0
wg set wg0 private-key /tmp/private.wg0
ip link set wg0 up
wg set wg0 listen-port $WG0_PORT

echo "net.ipv4.conf.all.rp_filter = 0">/etc/sysctl.conf
echo "net.ipv4.conf.default.rp_filter = 0" >>/etc/sysctl.conf
echo "net.ipv4.conf.eth0.rp_filter = 0" >>/etc/sysctl.conf
echo "net.ipv4.conf.wg0.rp_filter = 0" >>/etc/sysctl.conf
sysctl -p

iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE


while [ 1 ]; do
    sleep 65565
done
