#!/bin/bash
sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine
sudo yum install -y yum-utils
##添加yum源
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce docker-ce-cli containerd.io
#特定版本docker
#yum list docker-ce --showduplicates | sort -r
#sudo yum install docker-ce-<VERSION_STRING> docker-ce-cli-<VERSION_STRING> containerd.io
systemctl start docker
#设置开机启动
systemctl enable docker
##验证是否安装成功
docker info
#docker-compose
curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

chmod +x ./work/*.sh
chmod +x ./work/sh/*.sh
# 随机端口$((RANDOM+20000))
docker-compose up -d
#设置开机启动
sudo echo "/usr/local/bin/docker-compose -f /root/docker-compose.yml up -d" >> /etc/rc.d/rc.local
